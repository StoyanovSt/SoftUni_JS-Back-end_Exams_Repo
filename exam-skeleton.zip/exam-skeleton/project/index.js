const express = require('express');
const app = express();
const port = 5000;
const handlebars = require('express-handlebars');
const mongoose = require('mongoose');
// models
const User = require('./models/User');
const Expense = require('./models/Expense');
const regexPattern = /^[a-zA-Z0-9]{5,}$/;


const cookieParser = require('cookie-parser');
const bcrypt = require('bcrypt');
const saltRounds = 9;
const jwt = require('jsonwebtoken');
const SECRET = 'private';
const USER_SESSION = 'USER_SESSION';

// authentication & athtorization middlewares
const isAuth = require('./middlewares/isAuth');
// const isAuthorized = require('./middlewares/isAuthorized');

// routes guards
const isGuest = require('./middlewares/isGuest');
const isAlreadyLoggedIn = require('./middlewares/isAlreadyLoggedIn');


//----------------------------------------------------------------------------------
// app config

// view engine config
app.engine('hbs', handlebars({
    extname: 'hbs'
}));
app.set('view engine', 'hbs');

// Middleware за статичните файлове
app.use(express.static('public'));

// body parser
app.use(express.urlencoded({
    extended: true
}));

// set up mongoose
mongoose.connect('mongodb://localhost:27017/expenses', { useNewUrlParser: true, useUnifiedTopology: true });

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => console.log('Connected to the database.'));

mongoose.set('useNewUrlParser', true);
mongoose.set('useFindAndModify', true);
mongoose.set('useCreateIndex', true);

// cookie parser
app.use(cookieParser());

app.use(isAuth);
// app.use(isAuthorized);


//------------------------------------------------------------
// actions

// home
app.get('/', (req, res) => {
    let username = '';
    let isCurrentUserAuthenticated = false;

    if (req.cookies[USER_SESSION]) {
        username = res.locals.user.username;
        isCurrentUserAuthenticated = res.locals.isAuthenticated;
    }

    // get all expenses of current user
    if (req.user) {
        const currentLoggedUserId = req.user._id;

        Expense.find()
            .where({ user: currentLoggedUserId })
            .lean()
            .then(expenses => {

                res.render('home', { username, isCurrentUserAuthenticated, expenses });
            })
            .catch(err => {
                console.log(err);
            });
    } else {
        res.render('home', { username, isCurrentUserAuthenticated });
    }
});

// auth
app.get('/register', (req, res) => {
    res.render('register');
});


app.post('/register', (req, res) => {
    let username = '';
    let isCurrentUserAuthenticated = false;

    if (req.cookies[USER_SESSION]) {
        username = res.locals.user.username;
        isCurrentUserAuthenticated = res.locals.isAuthenticated;
    }

    // get user data
    const userData = req.body;

    // validate data
    if (!regexPattern.test(userData.username)) {
        const error = new Error('Invalid username or password!');

        res.render('register', { error });
        return;
    }

    if (userData.password.length < 4) {
        const error = new Error('Invalid username or password!');

        res.render('register', { error });
        return;
    }

    if (userData.amount < 0) {
        const error = new Error('Invalid inputs!');

        res.render('register', { error });
        return;
    }

    // TO DO: chech if such user exists in database
    User.findOne({ username: userData.username })
        .then(user => {
            if (user) {
                const error = new Error('User already exists');

                res.render('register', { error });
            } else {
                // validate username, password and rePassword
                if (userData.password !== userData.rePassword) {
                    const error = new Error('Passwords do not match!');

                    res.render('register', { error });
                    return;
                }

                // hash password
                bcrypt.genSalt(saltRounds)
                    .then(salt => {
                        bcrypt.hash(userData.password, salt)
                            .then(hash => {
                                // store in database
                                const user = new User({ username: userData.username, password: hash, amount: userData.amount });
                                user.save()
                                    .then(response => {
                                        // redirect to home page / call login function
                                        res.redirect('/');

                                    })
                                    .catch(error => {
                                        console.log(error);
                                    });
                            })
                            .catch(error => {
                                console.log(error);
                            });
                    })
                    .catch(error => {
                        console.log(error);
                    });
            }
        })
        .catch(error => {
            console.log(error);
        });

});

app.get('/login', (req, res) => {
    res.render('login');
});


app.post('/login', (req, res) => {
    let username = '';
    let isCurrentUserAuthenticated = false;

    if (req.cookies[USER_SESSION]) {
        username = res.locals.user.username;
        isCurrentUserAuthenticated = res.locals.isAuthenticated;
    }

    // get user data
    const userData = req.body;

    // validate data
    if (!regexPattern.test(userData.username)) {
        const error = new Error('Invalid username or password!');

        res.render('login', { error });
        return;
    }

    if (userData.password.length < 4) {
        const error = new Error('Invalid username or password!');

        res.render('login', { error });
        return;
    }

    // check if such user exists and if so
    User.findOne({ username: userData.username })
        .then(user => {
            if (!user) {
                // in case of error - re render login page with error message
                const error = new Error('Invalid username or password!');
                res.render('login', { error });
                return;
            }

            // check if passwords match
            bcrypt.compare(userData.password, user.password)
                .then(response => {
                    if (!response) {
                        const error = new Error('Invalid username or password!');
                        res.render('login', { error });
                        return;
                    }

                    // generate jwt and send it to the client as cookie
                    const token = jwt.sign({
                        _id: user._id,
                        username: user.username
                    }, SECRET);

                    res.cookie(USER_SESSION, token, { httpOnly: true });
                    // redirect to home page as logged user
                    res.redirect('/');

                })
                .catch(err => {
                    console.log(err);
                });

        })
        .catch(error => {
            console.log(error);
        });
});

app.get('/logout', (req, res) => {
    res.clearCookie(USER_SESSION);
    res.redirect('/');
});

// expenses

app.get('/expense/create', (req, res) => {
    let username = '';
    let isCurrentUserAuthenticated = false;

    if (req.cookies[USER_SESSION]) {
        username = res.locals.user.username;
        isCurrentUserAuthenticated = res.locals.isAuthenticated;
    }

    res.render('new-expense', { username, isCurrentUserAuthenticated });
});

app.post('/expense/create', (req, res) => {
    let username = '';
    let isCurrentUserAuthenticated = false;

    if (req.cookies[USER_SESSION]) {
        username = res.locals.user.username;
        isCurrentUserAuthenticated = res.locals.isAuthenticated;
    }

    // get data
    let { merchant, total, category, description, report } = req.body;

    //validate data
    if (merchant.length < 4) {
        const error = new Error('Merchant should be atleast 4 characters long!');

        res.render('new-expense', { error, username, isCurrentUserAuthenticated });
        return;
    }

    if (total < 0) {
        const error = new Error('Total should be a positive number!');

        res.render('new-expense', { error, username, isCurrentUserAuthenticated });
        return;
    }

    // transform chechbox value to boolean
    if (report !== undefined) {
        report = true;
    }

    // validate data - mongoose validation for now

    // store in database
    const expense = new Expense({
        merchant: merchant,
        total: total,
        category: category,
        description: description,
        report: report,
        user: req.user._id,
    });


    expense.save()
        .then(expense => {
            // get current user
            User.findById(req.user._id)
                .then(user => {
                    user.expenses.push(expense._id);
                    return user.save();
                })
                .then(response => {
                    // redirect home
                    res.redirect('/');
                })
                .catch(err => {
                    console.log(err);
                });

        })
        .catch(err => {
            const error = new Error('Invalid inputs!');

            res.render('new-expense', { error });
        });
});

app.get('/expense/details/:expenseId', async (req, res) => {
    let username = '';
    let isCurrentUserAuthenticated = false;

    if (req.cookies[USER_SESSION]) {
        username = res.locals.user.username;
        isCurrentUserAuthenticated = res.locals.isAuthenticated;
    }

    // get expense id
    const expenseId = req.params.expenseId;

    // get expense info from database and render details page
    const expenseInfo = await Expense.findById(expenseId).lean();

    // let amITheCreator = false;

    // if (req.cookies[USER_SESSION] && res.locals.user._id == articleInfo.articleAuthor) {
    //     amITheCreator = true;
    // }

    res.render('report', { expenseInfo, username, isCurrentUserAuthenticated });
});

app.get('/expense/stopTracking/:expenseId', (req, res) => {
    // get expense id
    const expenseId = req.params.expenseId;

    // find it is database by id and delete it
    Expense.findByIdAndDelete(expenseId)
        .then(response => {
            // redirect home
            res.redirect('/');
        })
        .catch(err => {
            console.log(err);
        });
});

app.post('/refill', (req, res) => {
    // get data
    const refillingAmount = Number(req.body.refillAmount);

    // get current user
    User.findById(req.user._id)
        .then(user => {
            user.amount += refillingAmount;
            return user.save();
        })
        .then(userRefilled => {
            res.redirect('/');
        })
        .catch(err => {
            console.log(err);
        });
});


// bonus page
app.get('/profile', (req, res) => {
    let username = '';
    let isCurrentUserAuthenticated = false;

    if (req.cookies[USER_SESSION]) {
        username = res.locals.user.username;
        isCurrentUserAuthenticated = res.locals.isAuthenticated;
    }

    // get all expenses from database
    let userTotalAmountOfExpenses = 0;
    let totalMerchants = 0;
    let availableAccAmount = 0;
    // get current user
    User.findById(req.user._id)
        .populate('expenses')
        .then(user => {
            user.expenses.forEach(expense => {
                userTotalAmountOfExpenses += Number(expense.total);
            });

            totalMerchants = user.expenses.length;

            availableAccAmount = user.amount;

            user.expenses.forEach(expense => {
                availableAccAmount -= Number(expense.total);
            });

            res.render('account-info', { username, isCurrentUserAuthenticated, userTotalAmountOfExpenses, totalMerchants, availableAccAmount });
        })
        .catch(err => {
            console.log(err);
        });

});

// not found page
app.get('*', (req, res) => {
    let username = '';
    let isCurrentUserAuthenticated = false;

    if (req.cookies[USER_SESSION]) {
        username = res.locals.user.username;
        isCurrentUserAuthenticated = res.locals.isAuthenticated;
    }

    // get current user
    User.findById(req.user._id)
        .then(user => {
            res.render('404-and-notifications', { user, username, isCurrentUserAuthenticated });
        })
        .catch(err => {
            console.log(err);
        });
});


app.listen(port, () => {
    console.log(`Server is listening on port ${port}...`);
});

