const mongoose = require('mongoose');

const expenseSchema = new mongoose.Schema({
    merchant: {
        type: String,
        require: true,

    },
    total: {
        type: Number,
        require: true,

    },
    category: {
        type: String,
        require: true,
    },
    description: {
        type: String,
        require: true,
        minlength: 3,
        maxlength: 30
    },
    report: {
        type: Boolean,
        require: true,
        default: false,
    },
    user: {
        type: mongoose.Types.ObjectId,
        ref: 'User',
        require: true,
    }

});

module.exports = mongoose.model('Expense', expenseSchema);