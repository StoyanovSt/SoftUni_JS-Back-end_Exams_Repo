const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        require: true,
        unique: true,
    },
    password: {
        type: String,
        require: true,
    },
    amount:{
        type: Number,
        require: true,
        default: 0,
    },
    expenses: [{
        type: mongoose.Types.ObjectId,
        ref: 'Expense'
    },
    ]
});

module.exports = mongoose.model('User', userSchema);