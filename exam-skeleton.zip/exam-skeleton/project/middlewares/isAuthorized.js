module.exports = function (req, res, next) {
    // ако isAuthenticanted middleware-a не е закачил user data-та към req-та, то usera няма token или има невалиден token
    // следователно не е оторизиран
    if (!req.user) {
        // пренасочваме го да се логне
        res.redirect('/login');
    } else {
        // иначе - да продължи
        next();
    }

}