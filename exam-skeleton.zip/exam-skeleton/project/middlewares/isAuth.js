const COOKIE_NAME = 'USER_SESSION';
const jwt = require('jsonwebtoken');
const SECRET = 'private';

module.exports = (req, res, next) => {
    // check if current user has jwt as cookie
    if (req.cookies[COOKIE_NAME]) {
        const token = req.cookies[COOKIE_NAME];

        // verify jwt and delete cookie if jwt not valid
        jwt.verify(token, SECRET, (err, decoded) => {
            if (err) {
                res.clearCookie(COOKIE_NAME);
            } else {
                // attack user data to req for personalization
                req.user = decoded;
                // attach user info to respons-a to be rendered, но си е на ниво server, не стига до client-a, за Handlebars си е
                res.locals.user = decoded;
                res.locals.isAuthenticated = true;
            }
        });
    }

    next();    
        
};