// явава се като междинна проверка
module.exports = (req, res, next) => {
    if (!req.user) {
        // if current unlogged user tries to get logged user's pages like create article for example - redirect to login, and return
        res.redirect('/login');
        return;

    }
    // иначе - продължи с заявката от req-та
    next();
};