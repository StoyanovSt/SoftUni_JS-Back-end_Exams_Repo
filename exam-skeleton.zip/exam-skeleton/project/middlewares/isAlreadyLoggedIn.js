// явава се като междинна проверка
module.exports = (req, res, next) => {
    if (req.user) {
        // if current logged user tries to get guest user's pages like login for example - redirect to home, and return
        res.redirect('/');
        return;
    }

    // иначе - продължи с заявката от req-та, демек - ОК няма токен и страниците, които не изискват токен могат да бъдат визуализирани
    next();
};